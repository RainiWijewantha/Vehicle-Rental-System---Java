/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Sashee
 */
public class GetData {
    public static ResultSet getData(String query){
        
        Connection con=null;
        ResultSet rs=null;
        Statement st=null;
        
        try{
            con=Connect.ConnectDB();
            st=con.createStatement();
            rs=st.executeQuery(query);
            
            return rs;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
        
        
    }
}
