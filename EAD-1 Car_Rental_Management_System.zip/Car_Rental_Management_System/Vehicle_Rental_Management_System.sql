CREATE DATABASE Vehicle_Rental_Management_System;

CREATE TABLE Users
(
	fn			VARCHAR(100),
    ln			VARCHAR(100),
    un			VARCHAR(100)			PRIMARY KEY,
    email		VARCHAR(100),
    pass		VARCHAR(50),
    que			VARCHAR(100),
    ans			VARCHAR(100),
    address		VARCHAR(100),
    tel			VARCHAR(15)
);

select * from Users;

CREATE TABLE Bikes
(
	BikeId				VARCHAR(10)				PRIMARY KEY,
    B_NumberPlate			VARCHAR(20),
    B_Color				VARCHAR(10),
    B_Brand				VARCHAR(20),
    B_MaxPersons			INT
);

select * from Bikes;

CREATE TABLE Cars
(
	CarId				VARCHAR(10)				PRIMARY KEY,
    C_NumberPlate			VARCHAR(20),
    C_Color				VARCHAR(10),
    C_Brand				VARCHAR(20),
    C_MaxPersons			INT
);

select * from Cars;

CREATE TABLE Vans
(
	VanId				VARCHAR(10)				PRIMARY KEY,
    V_NumberPlate			VARCHAR(20),
    V_Color				VARCHAR(10),
    V_Brand				VARCHAR(20),
    V_MaxPersons			INT
);

select * from Vans;

CREATE TABLE Owner
(
	OwnerId			VARCHAR(50)				PRIMARY KEY,
    OwnerName		VARCHAR(100),
    OwnerNIC		VARCHAR(20),
    OwnerTelephone	VARCHAR(15),
    OwnerAddress	VARCHAR(100),
    OwnerEmail		VARCHAR(100),
    VehicleNumber	VARCHAR(20)
);

select * from Owner;

CREATE TABLE Customer
(
	CustomerId			VARCHAR(50)				PRIMARY KEY,
    CustomerFirstName	VARCHAR(100),
    CustomerLastName	VARCHAR(100),
    CustomerNIC			VARCHAR(20),
    CustomerAddress		VARCHAR(100),
    CustomerTelephone	VARCHAR(15),
    CustomerEmail		VARCHAR(100),
    VehicleId			VARCHAR(5)
);

select * from Customer;